<?php 

include_once('../config/config.php');
require_once('../common/page-top.php'); 
// include_once('../config/dbconfig.php');
// $db = new dbconfig();

// session_start();
    if (!isset($_SESSION['loggedin'])) {
        header('Location: ../index.php');
        exit;
    }





?>
<?php

$condition	=	'';
if(isset($_REQUEST['emp_code']) and $_REQUEST['emp_code']!=""){
    $condition	.=	' AND emp_code LIKE "%'.$_REQUEST['emp_code'].'%" ';
}
if(isset($_REQUEST['emp_fname']) and $_REQUEST['emp_fname']!=""){
    $condition	.=	' AND emp_fname LIKE "%'.$_REQUEST['emp_fname'].'%" ';
}
// if(isset($_REQUEST['comp_branch']) and $_REQUEST['comp_branch']!=""){
//     $condition	.=	' AND comp_branch LIKE "%'.$_REQUEST['comp_branch'].'%" ';
// }

// if(isset($_REQUEST['comp_status']) and $_REQUEST['comp_status']!=""){
//     $condition	.=	' AND comp_status LIKE "'.$_REQUEST['comp_status'].'" ';
// }

// if(isset($_REQUEST['ac_trans_mode']) and $_REQUEST['ac_trans_mode']!=""){
//     $condition	.=	' AND ac_trans_mode LIKE "%'.$_REQUEST['ac_trans_mode'].'%" ';
// }

// if((isset($_REQUEST['fromdate']) and $_REQUEST['fromdate']!="") && (isset($_REQUEST['todate']) and $_REQUEST['todate']!="")){
//     $condition	.=	' AND ac_trans_date BETWEEN "'.$_REQUEST['fromdate'].'" AND "'.$_REQUEST['todate'].'" ';
// }

// if(isset($_REQUEST['fromdate']) and $_REQUEST['fromdate']!=""){
//     $condition	.=	' AND ac_trans_date LIKE "'.$_REQUEST['fromdate'].'"  ';
// }

// ------------- Debit total statement -----------

// $qry = "SELECT SUM(ac_amount) AS count FROM complaint_register WHERE ac_trans_type='Debit'  ".$condition."";

// $res = $dbcon->connection->query($qry);
// $total = 0;
// $rec =  $res->fetch_assoc();
// $total = $rec['count'];

// ------------- Credit  total statement -----------
// $qry1 = "SELECT SUM(ac_amount) AS count  FROM complaint_register WHERE ac_trans_type='Credit' ".$condition."";

// $res1 = $dbcon->connection->query($qry1);
// $ctotal = 0;
// $rec1 =  $res1->fetch_assoc();
// $ctotal = $rec1['count'];

 //Main queries
 $pages->default_ipp	=	15;
 $sql 	= $db->getRecFrmQry("SELECT * FROM employee WHERE 1 ".$condition."");
 $pages->items_total	=	count($sql);
 $pages->mid_range	=	9;
 $pages->paginate(); 
$employeeData	=   $db->getRecFrmQry("SELECT * FROM employee WHERE 1 ".$condition." ORDER BY emp_code ASC ".$pages->limit."");

?>

<body class="animsition">

    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php require_once('../common/header.php');  ?>
        <!-- END HEADER MOBILE-->
        <!-- MENU SIDEBAR-->
        <?php require_once('../common/sidebar.php');  ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->

            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                    <h2 class="title-1">Employee List</h2>
                                </div>
                            </div>
                        </div>



                        <div class="card">

                            <div class="card-header"><i class="fa fa-fw fa-search"></i> <strong>Search</strong> <a
                                    href="../view/employee-enroll.php" class="float-right btn btn-dark btn-sm"><i
                                        class="fa fa-fw fa-plus-circle"></i> Enroll Employee</a></div>

                            <div class="card-body">

                                <?php

    if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rds"){

        echo  	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Transaction Id: '. $_SESSION['deleteid'] . '  Record deleted successfully!</div>';

    }elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rus"){

        echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record updated successfully!</div>';

    }elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rnu"){

        echo	'<div class="alert alert-warning"><i class="fa fa-exclamation-triangle"></i> You did not change any thing!</div>';

    }elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ras"){

        echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record added successfully!</div>';

    }elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rna"){

        echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Record not added <strong>Please try again!</strong></div>';

    }

    ?>

                                <div class="col-sm-12">



                                    <form method="get">

                                        <div class="row">

                                            <div class="col-sm-3">

                                                <div class="form-group">

                                                    <label>Employee#</label>

                                                    <input type="text" name="emp_code" id="emp_code"
                                                        class="form-control"
                                                        value="<?php echo isset($_REQUEST['emp_code'])?$_REQUEST['emp_code']:''?>"
                                                        placeholder="Enter Employee number">

                                                </div>

                                            </div>
                                            <div class="col-sm-5">

                                                <div class="form-group">

                                                    <label>Employee Name</label>
                                                    <input type="text" class="tel form-control" name="emp_fname"
                                                        id="emp_fname"
                                                        value="<?php echo isset($_REQUEST['emp_fname'])?$_REQUEST['emp_fname']:''?>"
                                                        placeholder="Enter employee name">

                                                </div>

                                            </div>
                                         
                                            <div class="col-sm-4">

                                                <div class="form-group">

                                               
                                                <button type="submit" name="submit" value="search" id="submit"
                                                            class="btn btn-primary"><i class="fa fa-fw fa-search"></i>
                                                            </button>

                                                        <a href="<?php echo $_SERVER['PHP_SELF'];?>"
                                                            class="btn btn-danger ml-3"><i class="fa fa-fw fa-sync"></i>
                                                            </a>
                                                </div>

                                            </div>


                                        </div>
                                     
                                    </form>

                                </div>

                            </div>

                        </div>

                        <div class="clearfix"></div>

                        <div class="row marginTop">
                            <div class="col-sm-12 paddingLeft pagerfwt">
                                <?php if($pages->items_total > 0) { ?>
                                <?php echo $pages->display_pages();?>
                                <?php echo $pages->display_items_per_page();?>
                                <?php echo $pages->display_jump_menu(); ?>
                                <?php }?>
                            </div>
                            <div class="clearfix"></div>
                        </div>

                        <div class="clearfix"></div>

                        <div class="mt-2 mb-3">

                            <table class="table table-striped table-bordered">
                                <thead>
                            
                                    <tr class="bg-primary text-white">
                                        <th>Employee#</th>
                                        <th >Employee DP</th>
                                        <th width="100">Employee Name</th>
                                        <th>Address</th>
                                        <th>Date of Birth</th>
                                        <th>Status</th>                                      
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        if(count($employeeData)>0){
                                            $s	=	'';
                                            foreach($employeeData as $val){
                                                $s++;
                                            
                                        ?>
                                    <tr>

                                        <td><?php echo $val['emp_code'];?></td>
                                        <td><img src="<?php echo $val['emp_profile_img_path'] .$val['emp_profile_img_name'] ;?>" width="100" ></td>
                                        <td><?php echo $val['emp_fname']. " " . $val['emp_lname'];?></td>
                                        <td><?php echo $val['emp_paddress'] ;?></td>
                                        <td><?php echo $val['emp_dob'] ;?>
                                        </td>
                                        <td><?php echo $val['emp_status'] ?></td>
                                  
                                        <?php if( $_SESSION['adminlevel']==1 ) :?>
                                        <td align="center">
                                        <a href="employee-view.php?empid=<?php echo $val['emp_id'];?>"
                                                class="text-primary ml-2 mr-2"><i class="fa fa-fw fa-eye"></i></a>
                                            <a href="employee-edit.php?empid=<?php echo $val['emp_id'];?>"
                                                class="text-primary ml-2 mr-2"><i class="fa fa-fw fa-edit"></i></a> <br><br>
                                            <a href=""
                                                class="text-danger ml-2 mr-2"
                                                onClick="return confirm('Are you sure to delete this user?');"><i
                                                    class="fa fa-fw fa-trash"></i> </a>
                                                    </td>
                                                    <?php else : ?>

                                                        <td align="center">
                                            <a href="employee-view.php?empid=<?php echo $val['emp_id'];?>"
                                                class="text-primary ml-2 mr-2"><i class="fa fa-fw fa-eye"></i></a>
                                           <?php endif ?>
                                        </td>
                                     
                                    </tr>
                                    <?php 
            }
        }else{
        ?>
                                    <tr>
                                        <td colspan="5" align="center">No Record(s) Found!</td>
                                    </tr>
                                    <?php } ?>
                                  
                                </tbody>
                            </table>
                        </div>
                        <!--/.col-sm-12-->

                        <div class="clearfix"></div>

                        <div class="row marginTop">
                            <div class="col-sm-12 paddingLeft pagerfwt">
                                <?php if($pages->items_total > 0) { ?>
                                <?php echo $pages->display_pages();?>
                                <?php echo $pages->display_items_per_page();?>
                                <?php echo $pages->display_jump_menu(); ?>
                                <?php }?>
                            </div>
                            <div class="clearfix"></div>
                        </div>

                        <div class="clearfix"></div>



                        <!-- END FOOTER CONTENT-->
                        <?php require_once('../common/footer.php');  ?>
                        <!-- END FOOTER CONTAINER-->
                    </div>
                </div>
            </div>
        </div>
        <!-- END MAIN CONTENT-->
        <!-- END PAGE CONTAINER-->
    </div>

    </div>

    <?php require_once('../common/page-bottom.php');  ?>
</body>

</html>
<!-- end document-->