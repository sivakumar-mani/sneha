<?php 
    include_once('../config/config.php');
    require_once('../common/page-top.php'); 
session_start();
    if (!isset($_SESSION['loggedin'])) {
        header('Location: ../index.php');
        exit;
    }


if(isset($_REQUEST['submit']) and $_REQUEST['submit']!=""){

	extract($_REQUEST);

	if($transdate==""){

		header('location:'.$_SERVER['PHP_SELF'].'?msg=un');

		exit;

	}elseif($transmode==""){

		header('location:'.$_SERVER['PHP_SELF'].'?msg=ue');

		exit;

	}
    elseif($transname==""){

		header('location:'.$_SERVER['PHP_SELF'].'?msg=up');

		exit;

	}    elseif($transno==""){

		header('location:'.$_SERVER['PHP_SELF'].'?msg=up');

		exit;

	}
    elseif($transtype==""){

		header('location:'.$_SERVER['PHP_SELF'].'?msg=up');

		exit;

	}
    elseif($transamount==""){

		header('location:'.$_SERVER['PHP_SELF'].'?msg=up');

		exit;

	}
    elseif($transdetails==""){

		header('location:'.$_SERVER['PHP_SELF'].'?msg=up');

		exit;

	}
    
    
    
    else{

		

		$userCount	=	$db->getQueryCount('complaint_register','comp_id');



			$data	=	array(

							'ac_trans_date'=>$transdate,
                            'ac_trans_mode'=>$transmode,
							'ac_trans_type'=>$transtype,							
                            'trans_name'=>$transname,
                            'ac_trans_details'=>$transdetails,
                            'ac_trans_no'=>$transno,
                            'ac_amount'=>$transamount,
                            'ac_balance'=>0,
							);

			$insert	=	$db->insert('account_ledger',$data);

			if($insert){

				header('location:account-ledger.php?msg=ras');

				exit;

			}else{

				header('location:account-ledger.php?msg=rna');

				exit;

			}

	

	}

}
?>

<body class="animsition">

    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php require_once('../common/header.php');  ?>
        <!-- END HEADER MOBILE-->
        <!-- MENU SIDEBAR-->
        <?php require_once('../common/sidebar.php');  ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->

            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                    <h2 class="title-1">Add Complaint</h2>
                                </div>
                            </div>
                        </div>



                        <div class="card">

                            <div class="card-header"><i class="fa fa-fw fa-plus"></i> <strong>Add</strong> </div>

                            <div class="card-body">

                                <?php

if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="un"){

    echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> User name is mandatory field!</div>';

}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ue"){

    echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> User email is mandatory field!</div>';

}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="up"){

    echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> User phone is mandatory field!</div>';

}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ras"){

    echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record added successfully!</div>';

}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rna"){

    echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Record not added <strong>Please try again!</strong></div>';

}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="dsd"){

    echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Please delete a user and then try again <strong>We set limit for security reasons!</strong></div>';

}

?>

                                <form name="myForm" id="needs-validation" action="../model/contact_class.php"
                                    method="post" required>
                                    <div class="col-sm-12">
                                        <div class="row justify-content-between text-left ">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="comp_subject">Subject <sup>*</sup></label>
                                                    <select class="form-control demoInputBox" id="comp_subject"
                                                        name="comp_subject" onfocusout="myFunction()" required>
                                                        <option value="">Select Subject</option>
                                                        <option value="complaint">Complaint</option>
                                                        <option value="enquiry">Enquiry</option>\
                                                        <option value="Feedback">Feedback</option>
                                                        <option value="others">Others</option>
                                                    </select>
                                                    <div class="invalid-feedback">
                                                        Please selected any File.
                                                    </div>
                                                </div>
                                                <p id="demo"></p>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="comp_name">Reporter Name <sup>*</sup></label>
                                                    <input type="text" class="form-control demoInputBox" id="comp_name"
                                                        name="comp_name" placeholder="Please Enter your name" required>
                                                    <span id="comp_name-info" class="info"></span>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row justify-content-between text-left ">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="comp_email">Email address <sup>*</sup></label>
                                                    <input type="email" class="form-control demoInputBox"
                                                        id="comp_email" name="comp_email" placeholder="name@example.com"
                                                        required>
                                                    <span id="comp_email-info" class="info"></span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="comp_number">Contact Number <sup>*</sup></label>
                                                    <input type="number" class="form-control demoInputBox"
                                                        id="comp_number" name="comp_number"
                                                        placeholder="Please enter primary Number" required>
                                                    <span id="comp_number-info" class="info"></span>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="row justify-content-between text-left ">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="comp_bankname">Bank Name <sup>*</sup></label>
                                                    <input type="text" class="form-control demoInputBox"
                                                        id="comp_bankname" name="comp_bankname"
                                                        placeholder="Please enter Bank Name" required>
                                                    <span id="comp_bankname-info" class="info"></span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="comp_branch">Branch <sup>*</sup></label>
                                                    <input type="text" class="form-control demoInputBox"
                                                        id="comp_branch" name="comp_branch" maxlength="10"
                                                        placeholder="Please enter branch location" required>
                                                    <span id="comp_branch-info" class="info"></span>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="row justify-content-between text-left ">

                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="comp_baddress">Branch Address <sup>*</sup></label> <span
                                                        id="comp_baddress-info" class="info"></span>
                                                    <textarea class="form-control demoInputBox" id="comp_baddress"
                                                        name="comp_baddress" rows="3" required></textarea>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row justify-content-between text-left ">
                                            <div class="col-sm-12">

                                                <div class="form-group">
                                                    <label for="comp_comments">Message <sup>*</sup></label><span
                                                        id="comp_msg-info" class="info"></span>
                                                    <textarea class="form-control demoInputBox" id="comp_msg"
                                                        name="comp_msg" rows="3" required></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row ">
                                            <div class="col-sm-12 d-flex w-100 justify-content-between">
                                                <button type="reset" class="btn btn-dark">RESET</button>
                                                <button type="submit" class="btn btn-primary">SEND</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>


                            <div class="clearfix"></div>



                            <!-- END FOOTER CONTENT-->
                            <?php require_once('../common/footer.php');  ?>
                            <!-- END FOOTER CONTAINER-->
                        </div>
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <?php require_once('../common/page-bottom.php');  ?>
</body>

</html>
<!-- end document-->